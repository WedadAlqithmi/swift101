enum Level : String {
    case one = "Beginner"
    case two = "Master"
    case three = "Advance"
}

var userLevel : Level = .one


struct User {
    var name : String
    var point : Int
    var level : Level

}

var user = User(name: "Wedad", point: 1, level: .one)
user.level


func getSeconds (level : Level) -> Int {
    switch level {
    case .one:
        return 12
    case .two:
        return 8
    case .three:
        return 5

    }
}

print(getSeconds(level: user.level))
print(user.level.rawValue)
