
func msg(name: String){
    print("Congrats \(name)! 2000’s baby is now 2023’s graduate")
    }
    msg(name:"Wedad")

func getsum(num1: Int, num2:Int) -> Int {
    var res = num1 + num2
    return res
}
print (getsum(num1: 4, num2: 6))



func sub (num1: Int, num2: Int) -> Int{
    return num1 - num2
}
print(sub(num1: 10, num2: 6))


// with optional value
func subs (num3: Int?, num4: Int) -> Int{
    return ((num3 ?? 10) - num4)
}
print(subs(num3: nil, num4: 6))


// find the max & min number of an array
func getMinMax(arrNumbers : [Int]) -> (min:Int,max:Int){
    var minNum = arrNumbers[0]
    var maxNum = arrNumbers[0]
    
    for num in arrNumbers{
        if num < minNum{
            minNum = num
        }
        else if num > maxNum{
            maxNum = num
        }
    }
    return (minNum, maxNum)
}

var arrayNumbers = [3,4,5,6,7]
print(getMinMax(arrNumbers: arrayNumbers))

// to take minimum or the max value from the function
var minMax = getMinMax(arrNumbers: arrayNumbers)
print(minMax.min)
print(minMax.max)


func getPriceWithTax (price:Double ) -> Double {
    //var priceWithTax = price + (price * 0.05)
    return price + (price * 0.05)
}
print (getPriceWithTax(price: 100))


/* call by reference
 add "inout" to the recived vlaue type
 add "&" to the assigned value
 */
func getPriceWithTax (price:inout Double) -> Double {
    price = price + (price * 0.05)
    return price
}
var price = 100.0

print (getPriceWithTax(price: &price))


func operation(num1: Int, num2: Int) -> (sum:Int, sub:Int){
    func getSum () -> Int{
        return num1 + num2
    }
    func getSub () -> Int{
        return num1 - num2
    }
    return (getSub(),getSum())
}
print(operation(num1: 4, num2: 4))


func getFactorial(num : Int ) -> Int {
    if num == 1 {
        return 1
    }else{
        return num * getFactorial(num: num - 1)
    }
}
print(getFactorial(num: 5))


/*
 overloading functions
 the same function name but with different parameters
 */


func showWarningMessage (msg: String) {
    print (msg)
}


func showWarningMessage (msg: String, isFinish: Bool) {
    if isFinish{
        print ("\(msg) and close popup")}
    else{
        print(msg)
    }
}

showWarningMessage(msg: "no internet connection")
showWarningMessage(msg: "Comment sent successfully ", isFinish: true)
showWarningMessage(msg: "Comment sent successfully ", isFinish: false)

/*
 to return 2 arrays from the same function
 */
func getEvenOddNum (arrNumbers : [Int]) -> (arrEven: [Int], arrOdd: [Int]){
    var arrEvenNum = [Int]()
    var arrOddNum = [Int]()
    
    for num in arrNumbers{
        if num % 2 == 0 {
            arrEvenNum.append(num)
        }
        else {
            arrOddNum.append(num)
        }
    }
    return(arrEvenNum,arrOddNum)
}
print (getEvenOddNum(arrNumbers: [1,2,3,4,5,6,7,8]))


func getFilteredNumber (closure: (Int) -> Bool, arrNumbers:[Int]) -> [Int]{
    var arrFilteredNumbers = [Int] ()
    for num in arrNumbers{
        if closure(num){
            arrFilteredNumbers.append(num)
        }
    }
    return arrFilteredNumbers
}


/*
 the idea of closure is to send the check at the function call
 as you can see to the next line
 closure: { num in
     return num % 2 == 0
 the closure take the check of the number if it is an even number or not
 */
let arrFiltered = getFilteredNumber(closure: { num in
    return num % 2 == 0
}, arrNumbers: [2,4,5,6,7,8,9,88])
print (arrFiltered)


