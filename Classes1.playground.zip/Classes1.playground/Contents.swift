class Car{
    var name: String
    var color: String
    var model: Int
    
    init(name:String, color:String, model:Int){
        self.name = name
        self.color = color
        self.model = model
    }
    
    func move (){
        print("car is moving")
    }
}

// take object from the class
    
var car1 = Car(name: "Camry", color: "White", model: 2020)
print (car1.name)
    
var car2 = Car(name: "Mustang", color: "Black", model: 2020)
print (car2.name)

car1.move()

class Experts {
    var name :String
    var bio :String
    var likes :Int
    init(name: String, bio: String, likes: Int){
        self.name = name
        self.bio = bio
        self.likes = likes
    }
    
    func addNewLike(){
        likes+=1
    }
}
var expert1 = Experts(name: "Wedad", bio: "IOS Developer", likes: 100)
var expert2 = Experts(name: "Abdullah", bio: "Manager", likes: 100)

print(expert1.name)
print(expert1.likes)
expert1.addNewLike()
expert1.addNewLike()
print(expert1.likes)

//inheritance

class Developer : Experts{
    var arrProgLanuaes : [String]
    init(name: String, bio: String, likes: Int, arrProgLanuaes:[String]) {
        self.arrProgLanuaes = arrProgLanuaes
        super.init(name: name, bio: bio, likes: likes)
    }
    
}

class Laweyrs : Experts{
    var numberOfCases : Int
    init(name: String, bio: String, likes: Int, numberOfCases:Int) {
        self.numberOfCases = numberOfCases
        super.init(name: name, bio: bio, likes: likes)
    }
}
