var x = 5
var y = 3.5
var z = x + Int(y)

var a = 10, b = 3, c = 5
print("a + b = \(a+b)")
print("a * b = \(a*b)")
print("a - b = \(a-b)")
print("a / b = \(a/b)")
print("a % b = \(a%b)")

print((a+b)*c)

// Priority in mathematical operations ()  */  +-

a = a + 1
a += 2
a -= 1
a *= 5
a /= 6
a %= 3
